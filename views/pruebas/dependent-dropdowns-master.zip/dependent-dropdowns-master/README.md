# dependent-dropdowns

A small POC for a php implementation of dependent HTML dropdowns. This code is featured in [this video](https://youtu.be/GCaHIhcsFT8).

## Installation

The easiest way to use this code is to run it as a [Vagrant](https://www.vagrantup.com/) VM. Assuming you have vagrant installed run `vagrant up`

## Usage

Open a browser window at `http://localhost:8080`
